var searchData=
[
  ['off_5ftype',['off_type',['../classios__base.html#a8dec53328c2ca1883bc41d08022591c5',1,'ios_base']]],
  ['openmode',['openmode',['../classios__base.html#aaa192ec0dccc43050715553a34644523',1,'ios_base']]]
];

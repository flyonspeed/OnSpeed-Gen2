var searchData=
[
  ['sdspidriver',['SdSpiDriver',['../_sd_spi_arduino_driver_8h.html#ab862e944263a70d21beb329c59991191',1,'SdSpiArduinoDriver.h']]],
  ['spiport_5ft',['SpiPort_t',['../_sd_spi_arduino_driver_8h.html#a472d56ea7cb52ec5d68b3067baa000c3',1,'SdSpiArduinoDriver.h']]],
  ['stream_5ft',['stream_t',['../_sys_call_8h.html#af1b23f27ced3c86c519d99a7709a58bb',1,'SysCall.h']]],
  ['streamsize',['streamsize',['../classios__base.html#a944a240a54e6d0cef56540f2915e8d0e',1,'ios_base']]]
];

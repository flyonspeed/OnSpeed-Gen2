var searchData=
[
  ['ungetc',['ungetc',['../class_stdio_stream.html#ac00e0dd906c2e857ece53794c6c92786',1,'StdioStream']]],
  ['unselect',['unselect',['../class_sd_lib_spi_driver.html#a57af8105e517abe4fb93b671b571eedf',1,'SdLibSpiDriver']]],
  ['unsetf',['unsetf',['../classios__base.html#a3bf7d054a433ed15e8b984e16f630fa4',1,'ios_base']]],
  ['unusedstack',['UnusedStack',['../_free_stack_8h.html#a0a6400cf785c9647c0bacb76b15851de',1,'FreeStack.cpp']]],
  ['uppercase',['uppercase',['../ios_8h.html#af5d5e1a0effa1b500bb882feed5a2061',1,'ios.h']]],
  ['usedma',['useDma',['../class_sdio_config.html#a07ddb8b18bf24fa61fdd289a112e79a8',1,'SdioConfig']]]
];

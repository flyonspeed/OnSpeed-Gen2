// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleOnspeed_right_speaker[13249];
